# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class CitaMedicaConfig(AppConfig):
    name = 'cita_medica'
